def ask_ai(query):
    # Placeholder for LangChain / LLM response
    return f"[AI Response] You asked: '{query}'"