import os

# Dummy implementation – replace with actual Canvas API calls
def get_canvas_courses(student_id):
    return [
        {"name": "Intro to Data Science", "term": "Fall 2025"},
        {"name": "AI Ethics", "term": "Fall 2025"},
    ]